import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm

# Load AirPassengers dataset from R datasets
data = sm.datasets.get_rdataset("AirPassengers").data

# Convert to datetime and set index
data['Month'] = pd.date_range(start='1949-01', periods=len(data), freq='M')
data.set_index('Month', inplace=True)

# Rename column for clarity
data.rename(columns={'value': 'Passengers'}, inplace=True)

# Plot the time series
plt.figure(figsize=(10, 5))
plt.plot(data.index, data['Passengers'], marker='o', linestyle='-', color='blue')
plt.title("AirPassengers Time Series")
plt.xlabel("Year")
plt.ylabel("Number of Passengers")
plt.grid(True)
plt.tight_layout()
plt.show()

